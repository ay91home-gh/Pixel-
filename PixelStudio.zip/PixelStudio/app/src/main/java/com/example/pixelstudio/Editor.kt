package com.example.pixelstudio

import android.graphics.*
import android.text.StaticLayout
import android.text.TextPaint
import androidx.compose.runtime.*

private const val TINT = 0x558B7CFF

enum class Tool { Brush, Eraser, Move, Eyedropper, Fill, RectSel, Lasso, Wand, Text, Shape }

enum class Blend(val label: String, val mode: PorterDuff.Mode?) {
    Normal("عادي", null),
    Multiply("Multiply", PorterDuff.Mode.MULTIPLY),
    Screen("Screen", PorterDuff.Mode.SCREEN),
    Overlay("Overlay", PorterDuff.Mode.OVERLAY),
    Darken("Darken", PorterDuff.Mode.DARKEN),
    Lighten("Lighten", PorterDuff.Mode.LIGHTEN)
}

class Layer(val id: Int, name: String, val bitmap: Bitmap) {
    var name by mutableStateOf(name)
    var opacity by mutableFloatStateOf(1f)
    var blend by mutableStateOf(Blend.Normal)
    var visible by mutableStateOf(true)
    var locked by mutableStateOf(false)
}

class EditorState {
    val W = 1080
    val H = 1440
    val layers = mutableStateListOf<Layer>()
    var selectedId by mutableIntStateOf(-1)
    var tool by mutableStateOf(Tool.Brush)
    var color by mutableIntStateOf(Color.BLACK)
    var size by mutableFloatStateOf(28f)
    var hardness by mutableFloatStateOf(0.8f)
    var brushOpacity by mutableFloatStateOf(1f)
    var version by mutableIntStateOf(0)
    var zoom by mutableFloatStateOf(1f)
    var panX by mutableFloatStateOf(0f)
    var panY by mutableFloatStateOf(0f)
    var undoCount by mutableIntStateOf(0)
    var redoCount by mutableIntStateOf(0)
    val composite: Bitmap = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
    val sel: Bitmap = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
    var hasSel by mutableStateOf(false)
    var textX by mutableFloatStateOf(0f)
    var textY by mutableFloatStateOf(0f)
    var textDialog by mutableStateOf(false)
    var shapeKind by mutableIntStateOf(0)
    var shapeFill by mutableStateOf(false)
    private var shapeBase: Bitmap? = null
    var selVersion by mutableIntStateOf(0)
    private var selValid = false
    private val lasso = Path()
    private var lassoPts = 0
    private var clip: Bitmap? = null
    private val selPaint = Paint().apply { this.color = TINT; style = Paint.Style.FILL; isAntiAlias = false }

    private var nextId = 1
    private val undoS = ArrayDeque<Pair<Int, Bitmap>>()
    private val redoS = ArrayDeque<Pair<Int, Bitmap>>()
    private var cv: Canvas? = null
    private var paint = Paint()
    private val compPaint = Paint(Paint.FILTER_BITMAP_FLAG)

    init {
        val bg = newLayer("الخلفية")
        Canvas(bg.bitmap).drawColor(Color.WHITE)
        newLayer("طبقة 1")
    }

    fun active(): Layer? = layers.find { it.id == selectedId }

    fun refresh() {
        composite.eraseColor(0xFF2B2B33.toInt())
        val c = Canvas(composite)
        for (l in layers) if (l.visible) {
            compPaint.alpha = (l.opacity * 255).toInt()
            compPaint.xfermode = l.blend.mode?.let { PorterDuffXfermode(it) }
            c.drawBitmap(l.bitmap, 0f, 0f, compPaint)
        }
        version++
    }

    fun newLayer(name: String? = null): Layer {
        val l = Layer(nextId, name ?: "طبقة ${nextId}", Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888))
        nextId++
        layers.add(l); selectedId = l.id; refresh()
        return l
    }

    fun addImage(b: Bitmap) {
        val l = newLayer("صورة")
        val s = minOf(W.toFloat() / b.width, H.toFloat() / b.height)
        val w = b.width * s; val h = b.height * s
        val dst = RectF((W - w) / 2, (H - h) / 2, (W + w) / 2, (H + h) / 2)
        Canvas(l.bitmap).drawBitmap(b, null, dst, Paint(Paint.FILTER_BITMAP_FLAG))
        refresh()
    }

    fun duplicate() {
        val a = active() ?: return
        val l = newLayer(a.name + " نسخة")
        Canvas(l.bitmap).drawBitmap(a.bitmap, 0f, 0f, null)
        l.opacity = a.opacity; l.blend = a.blend
        refresh()
    }

    fun delete() {
        val a = active() ?: return
        if (layers.size <= 1) return
        layers.remove(a); selectedId = layers.last().id; refresh()
    }

    fun mergeDown() {
        val a = active() ?: return
        val i = layers.indexOf(a)
        if (i <= 0) return
        val below = layers[i - 1]
        pushUndo(below)
        val p = Paint(Paint.FILTER_BITMAP_FLAG)
        p.alpha = (a.opacity * 255).toInt()
        p.xfermode = a.blend.mode?.let { PorterDuffXfermode(it) }
        Canvas(below.bitmap).drawBitmap(a.bitmap, 0f, 0f, p)
        layers.remove(a); selectedId = below.id; refresh()
    }

    // ---- strokes ----
    fun beginStroke(): Boolean {
        val l = active() ?: return false
        if (l.locked || !l.visible) return false
        pushUndo(l)
        cv = Canvas(l.bitmap)
        val col = color
        val a = (brushOpacity * 255).toInt()
        val blur = size * (1f - hardness) * 0.5f
        val erase = tool == Tool.Eraser
        paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            if (erase) xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
            else { this.color = col; alpha = a }
            if (blur > 0.5f) maskFilter = BlurMaskFilter(blur, BlurMaskFilter.Blur.NORMAL)
        }
        return true
    }

    fun dot(x: Float, y: Float, p: Float) {
        val c = cv ?: return
        paint.style = Paint.Style.FILL
        c.drawCircle(x, y, size * (0.35f + 0.65f * p) / 2f, paint)
        paint.style = Paint.Style.STROKE
        refresh()
    }

    fun segment(x0: Float, y0: Float, x1: Float, y1: Float, p: Float) {
        val c = cv ?: return
        paint.strokeWidth = size * (0.35f + 0.65f * p)
        c.drawLine(x0, y0, x1, y1, paint)
        refresh()
    }

    fun endStroke() {
        val l = active()
        if (l != null && hasSel) { keepSelection(l); refresh() }
        cv = null
    }

    // ---- adjustments ----
    fun adjust(brightness: Float, saturation: Float) {
        val l = active() ?: return
        if (l.locked) return
        pushUndo(l)
        val cm = ColorMatrix().apply { setSaturation(saturation) }
        val b = brightness * 255f
        cm.postConcat(ColorMatrix(floatArrayOf(
            1f, 0f, 0f, 0f, b, 0f, 1f, 0f, 0f, b, 0f, 0f, 1f, 0f, b, 0f, 0f, 0f, 1f, 0f)))
        val tmp = l.bitmap.copy(Bitmap.Config.ARGB_8888, false)
        val c = Canvas(l.bitmap)
        c.drawColor(0, PorterDuff.Mode.CLEAR)
        c.drawBitmap(tmp, 0f, 0f, Paint().apply { colorFilter = ColorMatrixColorFilter(cm) })
        keepSelection(l)
        refresh()
    }

    // ---- undo / redo ----
    private fun snap(l: Layer) = l.id to l.bitmap.copy(Bitmap.Config.ARGB_8888, false)
    private fun sync() { undoCount = undoS.size; redoCount = redoS.size }
    private fun restore(l: Layer, b: Bitmap) {
        val c = Canvas(l.bitmap)
        c.drawColor(0, PorterDuff.Mode.CLEAR)
        c.drawBitmap(b, 0f, 0f, null)
    }

    private fun pushUndo(l: Layer) {
        undoS.addLast(snap(l))
        if (undoS.size > 10) undoS.removeFirst()
        redoS.clear(); sync()
    }

    fun undo() {
        val s = undoS.removeLastOrNull() ?: return
        layers.find { it.id == s.first }?.let { redoS.addLast(snap(it)); restore(it, s.second) }
        sync(); refresh()
    }

    fun redo() {
        val s = redoS.removeLastOrNull() ?: return
        layers.find { it.id == s.first }?.let { undoS.addLast(snap(it)); restore(it, s.second) }
        sync(); refresh()
    }


    // ---- view ----
    fun resetView() { zoom = 1f; panX = 0f; panY = 0f }

    fun cancelStroke() {
        val s = undoS.removeLastOrNull() ?: return
        layers.find { it.id == s.first }?.let { restore(it, s.second) }
        cv = null; sync(); refresh()
    }

    // ---- move ----
    private var moveBase: Bitmap? = null
    fun beginMove(): Boolean {
        val l = active() ?: return false
        if (l.locked) return false
        pushUndo(l)
        moveBase = l.bitmap.copy(Bitmap.Config.ARGB_8888, false)
        return true
    }
    fun moveTo(dx: Float, dy: Float) {
        val l = active() ?: return
        val b = moveBase ?: return
        val c = Canvas(l.bitmap)
        c.drawColor(0, PorterDuff.Mode.CLEAR)
        c.drawBitmap(b, dx, dy, null)
        refresh()
    }
    fun endMove() { moveBase = null }
    fun cancelMove() { cancelStroke(); moveBase = null }

    // ---- eyedropper / fill ----
    fun pick(x: Float, y: Float) {
        val xi = x.toInt(); val yi = y.toInt()
        if (xi in 0 until W && yi in 0 until H) color = composite.getPixel(xi, yi) or (0xFF shl 24)
    }

    private fun flood(px: IntArray, xi: Int, yi: Int, t: Int): BooleanArray {
        val target = px[yi * W + xi]
        fun near(a: Int): Boolean =
            Math.abs((a ushr 24) - (target ushr 24)) <= t &&
            Math.abs(((a shr 16) and 255) - ((target shr 16) and 255)) <= t &&
            Math.abs(((a shr 8) and 255) - ((target shr 8) and 255)) <= t &&
            Math.abs((a and 255) - (target and 255)) <= t
        val seen = BooleanArray(W * H)
        val stack = IntArray(W * H)
        var sp = 0
        stack[sp++] = yi * W + xi; seen[yi * W + xi] = true
        while (sp > 0) {
            val i = stack[--sp]
            val cx = i % W; val cy = i / W
            if (cx > 0 && !seen[i - 1] && near(px[i - 1])) { seen[i - 1] = true; stack[sp++] = i - 1 }
            if (cx < W - 1 && !seen[i + 1] && near(px[i + 1])) { seen[i + 1] = true; stack[sp++] = i + 1 }
            if (cy > 0 && !seen[i - W] && near(px[i - W])) { seen[i - W] = true; stack[sp++] = i - W }
            if (cy < H - 1 && !seen[i + W] && near(px[i + W])) { seen[i + W] = true; stack[sp++] = i + W }
        }
        return seen
    }

    fun fill(x: Float, y: Float) {
        val l = active() ?: return
        val xi = x.toInt(); val yi = y.toInt()
        if (l.locked || xi !in 0 until W || yi !in 0 until H) return
        pushUndo(l)
        val px = IntArray(W * H)
        l.bitmap.getPixels(px, 0, W, 0, 0, W, H)
        val reg = flood(px, xi, yi, 40)
        val nc = color or (0xFF shl 24)
        for (i in px.indices) if (reg[i]) px[i] = nc
        l.bitmap.setPixels(px, 0, W, 0, 0, W, H)
        keepSelection(l); refresh()
    }

    // ---- selection ----
    fun beginSel() { selValid = false }
    fun selRect(x0: Float, y0: Float, x1: Float, y1: Float) {
        sel.eraseColor(0)
        Canvas(sel).drawRect(minOf(x0, x1), minOf(y0, y1), maxOf(x0, x1), maxOf(y0, y1), selPaint)
        selValid = Math.abs(x1 - x0) > 2f && Math.abs(y1 - y0) > 2f
        hasSel = true; selVersion++
    }
    fun beginLasso(x: Float, y: Float) { lasso.reset(); lasso.moveTo(x, y); lassoPts = 1; selValid = false }
    fun lassoTo(x: Float, y: Float) {
        lasso.lineTo(x, y); lassoPts++
        sel.eraseColor(0)
        Canvas(sel).drawPath(lasso, selPaint)
        selValid = lassoPts > 3
        hasSel = true; selVersion++
    }
    fun endSel() { if (!selValid) deselect() }
    fun deselect() { sel.eraseColor(0); hasSel = false; selVersion++ }
    fun selectAll() { sel.eraseColor(TINT); hasSel = true; selVersion++ }

    fun wand(x: Float, y: Float) {
        val xi = x.toInt(); val yi = y.toInt()
        if (xi !in 0 until W || yi !in 0 until H) return
        val px = IntArray(W * H)
        composite.getPixels(px, 0, W, 0, 0, W, H)
        val reg = flood(px, xi, yi, 32)
        val out = IntArray(W * H) { if (reg[it]) TINT else 0 }
        sel.setPixels(out, 0, W, 0, 0, W, H)
        hasSel = true; selVersion++
    }

    fun invertSel() {
        val m = IntArray(W * H)
        sel.getPixels(m, 0, W, 0, 0, W, H)
        for (i in m.indices) m[i] = if ((m[i] ushr 24) == 0) TINT else 0
        sel.setPixels(m, 0, W, 0, 0, W, H)
        selVersion++
    }

    private fun restoreOutside(l: Layer, before: Bitmap) {
        if (!hasSel) return
        val a = IntArray(W * H); val m = IntArray(W * H); val b = IntArray(W * H)
        l.bitmap.getPixels(a, 0, W, 0, 0, W, H)
        sel.getPixels(m, 0, W, 0, 0, W, H)
        before.getPixels(b, 0, W, 0, 0, W, H)
        for (i in a.indices) if ((m[i] ushr 24) == 0) a[i] = b[i]
        l.bitmap.setPixels(a, 0, W, 0, 0, W, H)
    }

    private fun keepSelection(l: Layer) {
        val b = undoS.lastOrNull()?.second ?: return
        restoreOutside(l, b)
    }

    private fun applyToSel(l: Layer, f: (Int) -> Int) {
        val a = IntArray(W * H); val m = IntArray(W * H)
        l.bitmap.getPixels(a, 0, W, 0, 0, W, H)
        sel.getPixels(m, 0, W, 0, 0, W, H)
        for (i in a.indices) if ((m[i] ushr 24) != 0) a[i] = f(a[i])
        l.bitmap.setPixels(a, 0, W, 0, 0, W, H)
    }

    fun clearSel() {
        val l = active() ?: return
        if (!hasSel || l.locked) return
        pushUndo(l); applyToSel(l) { 0 }; refresh()
    }

    fun fillSel() {
        val l = active() ?: return
        if (!hasSel || l.locked) return
        val nc = color or (0xFF shl 24)
        pushUndo(l); applyToSel(l) { nc }; refresh()
    }

    fun copySel() {
        val l = active() ?: return
        if (!hasSel) return
        val a = IntArray(W * H); val m = IntArray(W * H)
        l.bitmap.getPixels(a, 0, W, 0, 0, W, H)
        sel.getPixels(m, 0, W, 0, 0, W, H)
        for (i in a.indices) if ((m[i] ushr 24) == 0) a[i] = 0
        val c = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        c.setPixels(a, 0, W, 0, 0, W, H)
        clip = c
    }

    fun cutSel() { copySel(); clearSel() }

    fun paste() {
        val c = clip ?: return
        val l = newLayer("لصق")
        Canvas(l.bitmap).drawBitmap(c, 0f, 0f, null)
        refresh()
    }

    // ---- text ----
    fun addText(text: String, px: Float, bold: Boolean, font: Int) {
        val col = color
        val base = when (font) { 1 -> Typeface.SERIF; 2 -> Typeface.MONOSPACE; else -> Typeface.SANS_SERIF }
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = col
            textSize = px
            typeface = Typeface.create(base, if (bold) Typeface.BOLD else Typeface.NORMAL)
        }
        val w = Math.ceil(StaticLayout.getDesiredWidth(text, tp).toDouble()).toInt().coerceIn(1, W)
        val layout = StaticLayout.Builder.obtain(text, 0, text.length, tp, w).build()
        val l = newLayer("نص: " + text.take(12))
        val c = Canvas(l.bitmap)
        c.translate(textX, textY)
        layout.draw(c)
        refresh()
    }

    // ---- shapes ----
    fun beginShape(): Boolean {
        val l = active() ?: return false
        if (l.locked) return false
        pushUndo(l)
        shapeBase = l.bitmap.copy(Bitmap.Config.ARGB_8888, false)
        return true
    }
    fun shapeTo(x0: Float, y0: Float, x1: Float, y1: Float) {
        val l = active() ?: return
        val b = shapeBase ?: return
        val col = color; val a = (brushOpacity * 255).toInt()
        val sw = size.coerceAtLeast(1f); val fillIt = shapeFill && shapeKind != 2
        val c = Canvas(l.bitmap)
        c.drawColor(0, PorterDuff.Mode.CLEAR)
        c.drawBitmap(b, 0f, 0f, null)
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            this.color = col; alpha = a
            style = if (fillIt) Paint.Style.FILL else Paint.Style.STROKE
            strokeWidth = sw; strokeCap = Paint.Cap.ROUND
        }
        when (shapeKind) {
            0 -> c.drawRect(minOf(x0, x1), minOf(y0, y1), maxOf(x0, x1), maxOf(y0, y1), p)
            1 -> c.drawOval(RectF(minOf(x0, x1), minOf(y0, y1), maxOf(x0, x1), maxOf(y0, y1)), p)
            else -> c.drawLine(x0, y0, x1, y1, p)
        }
        refresh()
    }
    fun endShape() {
        val l = active()
        if (l != null && hasSel) keepSelection(l)
        shapeBase = null; refresh()
    }
    fun cancelShape() { cancelStroke(); shapeBase = null }

    // ---- layer order / flip ----
    fun moveLayer(d: Int) {
        val a = active() ?: return
        val i = layers.indexOf(a); val j = i + d
        if (j < 0 || j >= layers.size) return
        layers.removeAt(i); layers.add(j, a); refresh()
    }
    fun flip(horizontal: Boolean) {
        val l = active() ?: return
        if (l.locked) return
        pushUndo(l)
        val tmp = l.bitmap.copy(Bitmap.Config.ARGB_8888, false)
        val m = Matrix()
        if (horizontal) m.setScale(-1f, 1f, W / 2f, H / 2f) else m.setScale(1f, -1f, W / 2f, H / 2f)
        val c = Canvas(l.bitmap)
        c.drawColor(0, PorterDuff.Mode.CLEAR)
        c.drawBitmap(tmp, m, null)
        keepSelection(l); refresh()
    }

    // ---- color adjust + filters ----
    fun adjustPro(bright: Float, contrast: Float, sat: Float, gamma: Float) {
        val l = active() ?: return
        if (l.locked) return
        pushUndo(l)
        val px = IntArray(W * H)
        l.bitmap.getPixels(px, 0, W, 0, 0, W, H)
        val lut = IntArray(256) {
            var v = Math.pow(it / 255.0, 1.0 / gamma).toFloat()
            v = (v - 0.5f) * contrast + 0.5f + bright
            (v * 255f + 0.5f).toInt().coerceIn(0, 255)
        }
        for (i in px.indices) {
            val p = px[i]
            val a = p ushr 24
            if (a == 0) continue
            var cr = (p shr 16) and 255; var cg = (p shr 8) and 255; var cb = p and 255
            val lum = 0.299f * cr + 0.587f * cg + 0.114f * cb
            cr = (lum + (cr - lum) * sat).toInt().coerceIn(0, 255)
            cg = (lum + (cg - lum) * sat).toInt().coerceIn(0, 255)
            cb = (lum + (cb - lum) * sat).toInt().coerceIn(0, 255)
            px[i] = (a shl 24) or (lut[cr] shl 16) or (lut[cg] shl 8) or lut[cb]
        }
        l.bitmap.setPixels(px, 0, W, 0, 0, W, H)
        keepSelection(l); refresh()
    }

    private fun blurPass(src: IntArray, dst: IntArray, horizontal: Boolean, r: Int) {
        val len = if (horizontal) W else H
        val lines = if (horizontal) H else W
        val step = if (horizontal) 1 else W
        val d = 2 * r + 1
        for (line in 0 until lines) {
            val base = if (horizontal) line * W else line
            var sa = 0; var sr = 0; var sg = 0; var sb = 0
            for (k in -r..r) {
                val c = src[base + k.coerceIn(0, len - 1) * step]
                sa += c ushr 24; sr += (c shr 16) and 255; sg += (c shr 8) and 255; sb += c and 255
            }
            for (k in 0 until len) {
                dst[base + k * step] = ((sa / d) shl 24) or ((sr / d) shl 16) or ((sg / d) shl 8) or (sb / d)
                val add = src[base + (k + r + 1).coerceAtMost(len - 1) * step]
                val rem = src[base + (k - r).coerceAtLeast(0) * step]
                sa += (add ushr 24) - (rem ushr 24)
                sr += ((add shr 16) and 255) - ((rem shr 16) and 255)
                sg += ((add shr 8) and 255) - ((rem shr 8) and 255)
                sb += (add and 255) - (rem and 255)
            }
        }
    }

    private fun boxBlur(px: IntArray, r: Int) {
        val tmp = IntArray(W * H)
        blurPass(px, tmp, true, r)
        blurPass(tmp, px, false, r)
    }

    // kind: 0 blur(amount=radius), 1 sharpen, 2 invert, 3 grayscale
    fun filter(kind: Int, amount: Int = 4) {
        val l = active() ?: return
        if (l.locked) return
        pushUndo(l)
        val px = IntArray(W * H)
        l.bitmap.getPixels(px, 0, W, 0, 0, W, H)
        when (kind) {
            0 -> boxBlur(px, amount)
            1 -> {
                val bl = px.copyOf()
                boxBlur(bl, 2)
                for (i in px.indices) {
                    val o = px[i]; val b = bl[i]
                    var out = o and (0xFF shl 24)
                    for (sh in intArrayOf(16, 8, 0)) {
                        val oc = (o shr sh) and 255; val bc = (b shr sh) and 255
                        out = out or ((oc + (oc - bc)).coerceIn(0, 255) shl sh)
                    }
                    px[i] = out
                }
            }
            2 -> for (i in px.indices) { val p = px[i]; px[i] = (p and (0xFF shl 24)) or (0xFFFFFF - (p and 0xFFFFFF)) }
            else -> for (i in px.indices) {
                val p = px[i]
                val g = (0.299f * ((p shr 16) and 255) + 0.587f * ((p shr 8) and 255) + 0.114f * (p and 255)).toInt()
                px[i] = (p and (0xFF shl 24)) or (g shl 16) or (g shl 8) or g
            }
        }
        l.bitmap.setPixels(px, 0, W, 0, 0, W, H)
        keepSelection(l); refresh()
    }

    fun exportBitmap(): Bitmap = composite.copy(Bitmap.Config.ARGB_8888, false)
}
