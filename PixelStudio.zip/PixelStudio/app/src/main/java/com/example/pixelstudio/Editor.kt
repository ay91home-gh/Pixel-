package com.example.pixelstudio

import android.graphics.*
import androidx.compose.runtime.*

enum class Tool { Brush, Eraser }

enum class Blend(val label: String, val mode: PorterDuff.Mode?) {
    Normal("عادي", null),
    Multiply("Multiply", PorterDuff.Mode.MULTIPLY),
    Screen("Screen", PorterDuff.Mode.SCREEN),
    Overlay("Overlay", PorterDuff.Mode.OVERLAY),
    Darken("Darken", PorterDuff.Mode.DARKEN),
    Lighten("Lighten", PorterDuff.Mode.LIGHTEN)
}

class Layer(val id: Int, name: String, val bitmap: Bitmap) {
    var name by mutableStateOf(name)
    var opacity by mutableFloatStateOf(1f)
    var blend by mutableStateOf(Blend.Normal)
    var visible by mutableStateOf(true)
    var locked by mutableStateOf(false)
}

class EditorState {
    val W = 1080
    val H = 1440
    val layers = mutableStateListOf<Layer>()
    var selectedId by mutableIntStateOf(-1)
    var tool by mutableStateOf(Tool.Brush)
    var color by mutableIntStateOf(Color.BLACK)
    var size by mutableFloatStateOf(28f)
    var hardness by mutableFloatStateOf(0.8f)
    var brushOpacity by mutableFloatStateOf(1f)
    var version by mutableIntStateOf(0)
    var undoCount by mutableIntStateOf(0)
    var redoCount by mutableIntStateOf(0)
    val composite: Bitmap = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)

    private var nextId = 1
    private val undoS = ArrayDeque<Pair<Int, Bitmap>>()
    private val redoS = ArrayDeque<Pair<Int, Bitmap>>()
    private var cv: Canvas? = null
    private var paint = Paint()
    private val compPaint = Paint(Paint.FILTER_BITMAP_FLAG)

    init {
        val bg = newLayer("الخلفية")
        Canvas(bg.bitmap).drawColor(Color.WHITE)
        newLayer("طبقة 1")
    }

    fun active(): Layer? = layers.find { it.id == selectedId }

    fun refresh() {
        composite.eraseColor(0xFF2B2B33.toInt())
        val c = Canvas(composite)
        for (l in layers) if (l.visible) {
            compPaint.alpha = (l.opacity * 255).toInt()
            compPaint.xfermode = l.blend.mode?.let { PorterDuffXfermode(it) }
            c.drawBitmap(l.bitmap, 0f, 0f, compPaint)
        }
        version++
    }

    fun newLayer(name: String? = null): Layer {
        val l = Layer(nextId, name ?: "طبقة ${nextId}", Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888))
        nextId++
        layers.add(l); selectedId = l.id; refresh()
        return l
    }

    fun addImage(b: Bitmap) {
        val l = newLayer("صورة")
        val s = minOf(W.toFloat() / b.width, H.toFloat() / b.height)
        val w = b.width * s; val h = b.height * s
        val dst = RectF((W - w) / 2, (H - h) / 2, (W + w) / 2, (H + h) / 2)
        Canvas(l.bitmap).drawBitmap(b, null, dst, Paint(Paint.FILTER_BITMAP_FLAG))
        refresh()
    }

    fun duplicate() {
        val a = active() ?: return
        val l = newLayer(a.name + " نسخة")
        Canvas(l.bitmap).drawBitmap(a.bitmap, 0f, 0f, null)
        l.opacity = a.opacity; l.blend = a.blend
        refresh()
    }

    fun delete() {
        val a = active() ?: return
        if (layers.size <= 1) return
        layers.remove(a); selectedId = layers.last().id; refresh()
    }

    fun mergeDown() {
        val a = active() ?: return
        val i = layers.indexOf(a)
        if (i <= 0) return
        val below = layers[i - 1]
        pushUndo(below)
        val p = Paint(Paint.FILTER_BITMAP_FLAG)
        p.alpha = (a.opacity * 255).toInt()
        p.xfermode = a.blend.mode?.let { PorterDuffXfermode(it) }
        Canvas(below.bitmap).drawBitmap(a.bitmap, 0f, 0f, p)
        layers.remove(a); selectedId = below.id; refresh()
    }

    // ---- strokes ----
    fun beginStroke(): Boolean {
        val l = active() ?: return false
        if (l.locked || !l.visible) return false
        pushUndo(l)
        cv = Canvas(l.bitmap)
        val col = color
        val a = (brushOpacity * 255).toInt()
        val blur = size * (1f - hardness) * 0.5f
        val erase = tool == Tool.Eraser
        paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            style = Paint.Style.STROKE
            strokeCap = Paint.Cap.ROUND
            strokeJoin = Paint.Join.ROUND
            if (erase) xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR)
            else { this.color = col; alpha = a }
            if (blur > 0.5f) maskFilter = BlurMaskFilter(blur, BlurMaskFilter.Blur.NORMAL)
        }
        return true
    }

    fun dot(x: Float, y: Float, p: Float) {
        val c = cv ?: return
        paint.style = Paint.Style.FILL
        c.drawCircle(x, y, size * (0.35f + 0.65f * p) / 2f, paint)
        paint.style = Paint.Style.STROKE
        refresh()
    }

    fun segment(x0: Float, y0: Float, x1: Float, y1: Float, p: Float) {
        val c = cv ?: return
        paint.strokeWidth = size * (0.35f + 0.65f * p)
        c.drawLine(x0, y0, x1, y1, paint)
        refresh()
    }

    fun endStroke() { cv = null }

    // ---- adjustments ----
    fun adjust(brightness: Float, saturation: Float) {
        val l = active() ?: return
        if (l.locked) return
        pushUndo(l)
        val cm = ColorMatrix().apply { setSaturation(saturation) }
        val b = brightness * 255f
        cm.postConcat(ColorMatrix(floatArrayOf(
            1f, 0f, 0f, 0f, b, 0f, 1f, 0f, 0f, b, 0f, 0f, 1f, 0f, b, 0f, 0f, 0f, 1f, 0f)))
        val tmp = l.bitmap.copy(Bitmap.Config.ARGB_8888, false)
        val c = Canvas(l.bitmap)
        c.drawColor(0, PorterDuff.Mode.CLEAR)
        c.drawBitmap(tmp, 0f, 0f, Paint().apply { colorFilter = ColorMatrixColorFilter(cm) })
        refresh()
    }

    // ---- undo / redo ----
    private fun snap(l: Layer) = l.id to l.bitmap.copy(Bitmap.Config.ARGB_8888, false)
    private fun sync() { undoCount = undoS.size; redoCount = redoS.size }
    private fun restore(l: Layer, b: Bitmap) {
        val c = Canvas(l.bitmap)
        c.drawColor(0, PorterDuff.Mode.CLEAR)
        c.drawBitmap(b, 0f, 0f, null)
    }

    private fun pushUndo(l: Layer) {
        undoS.addLast(snap(l))
        if (undoS.size > 10) undoS.removeFirst()
        redoS.clear(); sync()
    }

    fun undo() {
        val s = undoS.removeLastOrNull() ?: return
        layers.find { it.id == s.first }?.let { redoS.addLast(snap(it)); restore(it, s.second) }
        sync(); refresh()
    }

    fun redo() {
        val s = redoS.removeLastOrNull() ?: return
        layers.find { it.id == s.first }?.let { undoS.addLast(snap(it)); restore(it, s.second) }
        sync(); refresh()
    }

    fun exportBitmap(): Bitmap = composite.copy(Bitmap.Config.ARGB_8888, false)
}
