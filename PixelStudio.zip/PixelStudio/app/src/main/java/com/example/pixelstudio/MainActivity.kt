package com.example.pixelstudio

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.input.pointer.PointerInputChange
import androidx.compose.ui.input.pointer.PointerType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

private val violet = Color(0xFF8B7CFF)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    val st = remember { EditorState() }
    val ctx = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { u -> decode(ctx, u)?.let { st.addImage(it) } }
    }
    MaterialTheme(colorScheme = darkColorScheme(
        primary = violet, background = Color(0xFF14151A), surface = Color(0xFF1D1F27))) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                var sheet by remember { mutableStateOf(false) }
                BoxWithConstraints(Modifier.fillMaxSize()) {
                    val wide = maxWidth >= 840.dp
                    val export = { saveToGallery(ctx, st.exportBitmap()) }
                    if (wide) {
                        Row(Modifier.fillMaxSize()) {
                            Column(Modifier.weight(1f)) {
                                TopBar(st, export)
                                CanvasArea(st, Modifier.weight(1f).fillMaxWidth())
                                Options(st)
                                ToolsBar(st, { picker.launch("image/*") }, null)
                            }
                            LayersPanel(st, Modifier.width(300.dp).fillMaxHeight()
                                .background(MaterialTheme.colorScheme.surface))
                        }
                    } else {
                        Column(Modifier.fillMaxSize()) {
                            TopBar(st, export)
                            CanvasArea(st, Modifier.weight(1f).fillMaxWidth())
                            Options(st)
                            ToolsBar(st, { picker.launch("image/*") }) { sheet = true }
                        }
                        if (sheet) ModalBottomSheet(onDismissRequest = { sheet = false }) {
                            LayersPanel(st, Modifier.padding(bottom = 24.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun TopBar(st: EditorState, onExport: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Text("بيكسل ستوديو", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f).padding(start = 8.dp))
        IconButton(onClick = { st.undo() }, enabled = st.undoCount > 0) {
            Icon(Icons.AutoMirrored.Filled.Undo, "تراجع") }
        IconButton(onClick = { st.redo() }, enabled = st.redoCount > 0) {
            Icon(Icons.AutoMirrored.Filled.Redo, "إعادة") }
        Button(onClick = onExport) {
            Icon(Icons.Filled.Save, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("تصدير")
        }
    }
}

@Composable
fun CanvasArea(st: EditorState, modifier: Modifier) {
    Canvas(modifier.background(Color(0xFF0D0E12)).pointerInput(Unit) {
        awaitEachGesture {
            val sc = minOf(size.width.toFloat() / st.W, size.height.toFloat() / st.H)
            val ox = (size.width - st.W * sc) / 2f
            val oy = (size.height - st.H * sc) / 2f
            fun toDoc(p: Offset) = Offset((p.x - ox) / sc, (p.y - oy) / sc)
            fun pr(c: PointerInputChange) =
                if (c.type == PointerType.Stylus) c.pressure.coerceIn(0.1f, 1f) else 1f
            val down = awaitFirstDown(requireUnconsumed = false)
            if (!st.beginStroke()) return@awaitEachGesture
            var last = toDoc(down.position)
            st.dot(last.x, last.y, pr(down))
            down.consume()
            do {
                val ev = awaitPointerEvent()
                val ch = ev.changes.firstOrNull() ?: break
                if (ch.pressed) {
                    val p = toDoc(ch.position)
                    st.segment(last.x, last.y, p.x, p.y, pr(ch))
                    last = p
                    ch.consume()
                }
            } while (ev.changes.any { it.pressed })
            st.endStroke()
        }
    }) {
        st.version
        val sc = minOf(size.width / st.W, size.height / st.H)
        val w = (st.W * sc).roundToInt(); val h = (st.H * sc).roundToInt()
        drawImage(st.composite.asImageBitmap(),
            dstOffset = IntOffset(((size.width - w) / 2f).roundToInt(), ((size.height - h) / 2f).roundToInt()),
            dstSize = IntSize(w, h))
    }
}

@Composable
fun LabeledSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>,
                  modifier: Modifier, onChange: (Float) -> Unit) {
    Column(modifier) {
        Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}

@Composable
fun Options(st: EditorState) {
    Column(Modifier.background(MaterialTheme.colorScheme.surface).padding(horizontal = 12.dp, vertical = 4.dp)) {
        Row {
            LabeledSlider("الحجم ${st.size.toInt()}", st.size, 2f..150f, Modifier.weight(1f).padding(horizontal = 4.dp)) { st.size = it }
            LabeledSlider("الصلابة ${(st.hardness * 100).toInt()}%", st.hardness, 0f..1f, Modifier.weight(1f).padding(horizontal = 4.dp)) { st.hardness = it }
            LabeledSlider("التعتيم ${(st.brushOpacity * 100).toInt()}%", st.brushOpacity, 0.05f..1f, Modifier.weight(1f).padding(horizontal = 4.dp)) { st.brushOpacity = it }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            listOf(0xFF000000, 0xFFFFFFFF, 0xFFE53935, 0xFFFB8C00, 0xFFFDD835, 0xFF43A047, 0xFF1E88E5, 0xFF8E24AA).forEach { c ->
                val ci = c.toInt()
                Box(Modifier.size(34.dp).clip(CircleShape).background(Color(ci))
                    .border(if (st.color == ci) 3.dp else 1.dp, if (st.color == ci) violet else Color.Gray, CircleShape)
                    .clickable { st.color = ci; st.tool = Tool.Brush })
            }
        }
    }
}

@Composable
fun ToolsBar(st: EditorState, onImport: () -> Unit, onLayers: (() -> Unit)?) {
    Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface)
        .horizontalScroll(rememberScrollState()).padding(8.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        FilterChip(st.tool == Tool.Brush, { st.tool = Tool.Brush }, { Text("فرشاة") },
            leadingIcon = { Icon(Icons.Filled.Brush, null, Modifier.size(18.dp)) })
        FilterChip(st.tool == Tool.Eraser, { st.tool = Tool.Eraser }, { Text("ممحاة") })
        AssistChip(onClick = onImport, label = { Text("استيراد صورة") })
        AssistChip(onClick = { st.adjust(0.08f, 1f) }, label = { Text("سطوع +") })
        AssistChip(onClick = { st.adjust(-0.08f, 1f) }, label = { Text("سطوع −") })
        AssistChip(onClick = { st.adjust(0f, 1.25f) }, label = { Text("تشبع +") })
        AssistChip(onClick = { st.adjust(0f, 0.75f) }, label = { Text("تشبع −") })
        if (onLayers != null) AssistChip(onClick = onLayers, label = { Text("الطبقات (${st.layers.size})") },
            leadingIcon = { Icon(Icons.Filled.Layers, null, Modifier.size(18.dp)) })
    }
}

@Composable
fun LayersPanel(st: EditorState, modifier: Modifier = Modifier) {
    val sel = st.active()
    Column(modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("الطبقات", fontWeight = FontWeight.Bold)
        LazyColumn(Modifier.heightIn(max = 240.dp)) {
            items(st.layers.asReversed(), key = { it.id }) { l ->
                val on = l.id == st.selectedId
                Row(Modifier.fillMaxWidth().clip(MaterialTheme.shapes.small)
                    .background(if (on) violet.copy(alpha = 0.2f) else Color.Transparent)
                    .clickable { st.selectedId = l.id }.padding(start = 10.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(l.name, fontSize = 14.sp)
                        Text("${l.blend.label} · ${(l.opacity * 100).toInt()}%", fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton({ l.visible = !l.visible; st.refresh() }) {
                        Icon(if (l.visible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff, "إظهار/إخفاء") }
                    IconButton({ l.locked = !l.locked }) {
                        Icon(if (l.locked) Icons.Filled.Lock else Icons.Filled.LockOpen, "قفل") }
                }
            }
        }
        if (sel != null) {
            LabeledSlider("الشفافية ${(sel.opacity * 100).toInt()}%", sel.opacity, 0f..1f, Modifier) {
                sel.opacity = it; st.refresh() }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Blend.entries.forEach { b ->
                    FilterChip(sel.blend == b, { sel.blend = b; st.refresh() }, { Text(b.label) })
                }
            }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            AssistChip(onClick = { st.newLayer() }, label = { Text("طبقة جديدة") },
                leadingIcon = { Icon(Icons.Filled.Add, null, Modifier.size(18.dp)) })
            AssistChip(onClick = { st.duplicate() }, label = { Text("تكرار") })
            AssistChip(onClick = { st.mergeDown() }, label = { Text("دمج لأسفل") })
            AssistChip(onClick = { st.delete() }, label = { Text("حذف") },
                leadingIcon = { Icon(Icons.Filled.Delete, null, Modifier.size(18.dp)) })
        }
    }
}

fun decode(ctx: Context, uri: Uri): Bitmap? {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
    var s = 1
    while (o.outWidth / s > 2400 || o.outHeight / s > 2400) s *= 2
    val o2 = BitmapFactory.Options().apply { inSampleSize = s }
    return ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
}

fun saveToGallery(ctx: Context, bmp: Bitmap) {
    val v = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, "PixelStudio_${System.currentTimeMillis()}.png")
        put(MediaStore.Images.Media.MIME_TYPE, "image/png")
        put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/PixelStudio")
    }
    val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)
    if (uri == null) { Toast.makeText(ctx, "تعذّر الحفظ", Toast.LENGTH_SHORT).show(); return }
    ctx.contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
    Toast.makeText(ctx, "تم الحفظ في الصور/PixelStudio", Toast.LENGTH_LONG).show()
}
