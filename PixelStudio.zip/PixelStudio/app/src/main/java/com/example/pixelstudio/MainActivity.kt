package com.example.pixelstudio

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.PointerInputChange
import androidx.compose.ui.input.pointer.PointerType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.*
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { App() }
    }
}

private val violet = Color(0xFF8B7CFF)

private class TD(val tool: Tool, val icon: ImageVector, val label: String)

private val toolDefs = listOf(
    TD(Tool.Move, Icons.Filled.OpenWith, "تحريك"),
    TD(Tool.RectSel, Icons.Filled.SelectAll, "تحديد"),
    TD(Tool.Lasso, Icons.Filled.Gesture, "تحديد حر"),
    TD(Tool.Wand, Icons.Filled.AutoFixHigh, "العصا"),
    TD(Tool.Brush, Icons.Filled.Brush, "فرشاة"),
    TD(Tool.Eraser, Icons.Filled.CleaningServices, "ممحاة"),
    TD(Tool.Fill, Icons.Filled.FormatColorFill, "تعبئة"),
    TD(Tool.Eyedropper, Icons.Filled.Colorize, "قطّارة"),
    TD(Tool.Shape, Icons.Filled.CropSquare, "أشكال"),
    TD(Tool.Text, Icons.Filled.TextFields, "نص")
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun App() {
    val st = remember { EditorState() }
    val ctx = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let { u -> decode(ctx, u)?.let { st.addImage(it) } }
    }
    MaterialTheme(colorScheme = darkColorScheme(
        primary = violet, background = Color(0xFF14151A), surface = Color(0xFF1D1F27))) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                var sheet by remember { mutableStateOf(false) }
                if (st.textDialog) TextDialog(st)
                val surface = MaterialTheme.colorScheme.surface
                BoxWithConstraints(Modifier.fillMaxSize()) {
                    val wide = maxWidth >= 840.dp
                    val export = { saveToGallery(ctx, st.exportBitmap()) }
                    val import = { picker.launch("image/*") }
                    if (wide) {
                        Row(Modifier.fillMaxSize()) {
                            Column(Modifier.width(76.dp).fillMaxHeight().background(surface)
                                .verticalScroll(rememberScrollState()).padding(vertical = 8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                toolDefs.forEach { ToolButton(st.tool == it.tool, it.icon, it.label) { st.tool = it.tool } }
                            }
                            Column(Modifier.weight(1f)) {
                                TopBar(st, export)
                                ContextBar(st)
                                CanvasArea(st, Modifier.weight(1f).fillMaxWidth())
                            }
                            Column(Modifier.width(320.dp).fillMaxHeight().background(surface)) {
                                Row(Modifier.padding(horizontal = 8.dp)) { ActionButtons(st, import) }
                                ColorRow(st)
                                LayersPanel(st, Modifier.fillMaxWidth())
                            }
                        }
                    } else {
                        Column(Modifier.fillMaxSize()) {
                            TopBar(st, export)
                            CanvasArea(st, Modifier.weight(1f).fillMaxWidth())
                            ContextBar(st)
                            ColorRow(st)
                            Row(Modifier.fillMaxWidth().background(surface)
                                .horizontalScroll(rememberScrollState()).padding(horizontal = 6.dp, vertical = 4.dp)) {
                                toolDefs.forEach { ToolButton(st.tool == it.tool, it.icon, it.label) { st.tool = it.tool } }
                                ActionButtons(st, import)
                                ToolButton(false, Icons.Filled.Layers, "الطبقات") { sheet = true }
                            }
                        }
                        if (sheet) ModalBottomSheet(onDismissRequest = { sheet = false }) {
                            LayersPanel(st, Modifier.padding(bottom = 24.dp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ToolButton(on: Boolean, icon: ImageVector, label: String, onClick: () -> Unit) {
    Column(Modifier.size(width = 60.dp, height = 56.dp).clip(RoundedCornerShape(12.dp))
        .background(if (on) violet.copy(alpha = 0.25f) else Color.Transparent)
        .clickable(onClick = onClick),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Icon(icon, label, Modifier.size(24.dp),
            tint = if (on) violet else MaterialTheme.colorScheme.onSurface)
        Text(label, fontSize = 10.sp,
            color = if (on) violet else MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
fun ActionButtons(st: EditorState, onImport: () -> Unit) {
    var open by remember { mutableStateOf(false) }
    var adj by remember { mutableStateOf(false) }
    if (adj) AdjustDialog(st) { adj = false }
    ToolButton(false, Icons.Filled.Add, "صورة", onImport)
    Box {
        ToolButton(false, Icons.Filled.Tune, "تعديل") { open = true }
        DropdownMenu(open, { open = false }) {
            DropdownMenuItem({ Text("تعديل لوني…") }, { adj = true; open = false })
            DropdownMenuItem({ Text("تمويه خفيف") }, { st.filter(0, 3); open = false })
            DropdownMenuItem({ Text("تمويه قوي") }, { st.filter(0, 10); open = false })
            DropdownMenuItem({ Text("زيادة الحدة") }, { st.filter(1); open = false })
            DropdownMenuItem({ Text("عكس الألوان") }, { st.filter(2); open = false })
            DropdownMenuItem({ Text("تدرج رمادي") }, { st.filter(3); open = false })
            DropdownMenuItem({ Text("قلب أفقي") }, { st.flip(true); open = false })
            DropdownMenuItem({ Text("قلب رأسي") }, { st.flip(false); open = false })
        }
    }
    ToolButton(false, Icons.Filled.CenterFocusStrong, "ملاءمة") { st.resetView() }
}

@Composable
fun ShapeOptions(st: EditorState) {
    Column {
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("مستطيل", "دائرة", "خط").forEachIndexed { i, n ->
                FilterChip(st.shapeKind == i, { st.shapeKind = i }, { Text(n) })
            }
            FilterChip(st.shapeFill, { st.shapeFill = !st.shapeFill }, { Text("ممتلئ") })
        }
        LabeledSlider("السماكة ${st.size.toInt()}", st.size, 1f..80f, Modifier) { st.size = it }
    }
}

@Composable
fun TextDialog(st: EditorState) {
    var txt by remember { mutableStateOf("") }
    var sz by remember { mutableFloatStateOf(80f) }
    var bold by remember { mutableStateOf(true) }
    var font by remember { mutableIntStateOf(0) }
    AlertDialog(
        onDismissRequest = { st.textDialog = false },
        title = { Text("إضافة نص") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = txt, onValueChange = { txt = it }, label = { Text("النص") })
                LabeledSlider("الحجم ${sz.toInt()}", sz, 20f..300f, Modifier) { sz = it }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    FilterChip(bold, { bold = !bold }, { Text("عريض") })
                    listOf("Sans", "Serif", "Mono").forEachIndexed { i, n ->
                        FilterChip(font == i, { font = i }, { Text(n) })
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { if (txt.isNotBlank()) st.addText(txt, sz, bold, font); st.textDialog = false }) { Text("إضافة") }
        },
        dismissButton = { TextButton(onClick = { st.textDialog = false }) { Text("إلغاء") } }
    )
}

@Composable
fun AdjustDialog(st: EditorState, onClose: () -> Unit) {
    var b by remember { mutableFloatStateOf(0f) }
    var c by remember { mutableFloatStateOf(1f) }
    var s by remember { mutableFloatStateOf(1f) }
    var g by remember { mutableFloatStateOf(1f) }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("تعديل لوني") },
        text = {
            Column {
                LabeledSlider("السطوع ${(b * 100).toInt()}", b, -0.5f..0.5f, Modifier) { b = it }
                LabeledSlider("التباين ${(c * 100).toInt()}%", c, 0.5f..2f, Modifier) { c = it }
                LabeledSlider("التشبع ${(s * 100).toInt()}%", s, 0f..2f, Modifier) { s = it }
                LabeledSlider("الإضاءة (Gamma) ${"%.2f".format(g)}", g, 0.5f..2f, Modifier) { g = it }
            }
        },
        confirmButton = { TextButton(onClick = { st.adjustPro(b, c, s, g); onClose() }) { Text("تطبيق") } },
        dismissButton = { TextButton(onClick = onClose) { Text("إلغاء") } }
    )
}

@Composable
fun TopBar(st: EditorState, onExport: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(start = 8.dp)) {
            Text("بيكسل ستوديو", fontWeight = FontWeight.Bold)
            Text("${st.W}×${st.H} · ${st.layers.size} طبقات", fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        IconButton(onClick = { st.undo() }, enabled = st.undoCount > 0) {
            Icon(Icons.AutoMirrored.Filled.Undo, "تراجع") }
        IconButton(onClick = { st.redo() }, enabled = st.redoCount > 0) {
            Icon(Icons.AutoMirrored.Filled.Redo, "إعادة") }
        Button(onClick = onExport) {
            Icon(Icons.Filled.Save, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)); Text("تصدير")
        }
    }
}

@Composable
fun LabeledSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>,
                  modifier: Modifier, onChange: (Float) -> Unit) {
    Column(modifier) {
        Text(label, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Slider(value = value, onValueChange = onChange, valueRange = range)
    }
}

@Composable
fun ContextBar(st: EditorState) {
    val selTool = st.tool == Tool.RectSel || st.tool == Tool.Lasso || st.tool == Tool.Wand
    Column(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface)
        .padding(horizontal = 12.dp, vertical = 4.dp)) {
        when (st.tool) {
            Tool.Brush, Tool.Eraser -> Row {
                LabeledSlider("الحجم ${st.size.toInt()}", st.size, 2f..150f, Modifier.weight(1f).padding(horizontal = 4.dp)) { st.size = it }
                LabeledSlider("الصلابة ${(st.hardness * 100).toInt()}%", st.hardness, 0f..1f, Modifier.weight(1f).padding(horizontal = 4.dp)) { st.hardness = it }
                LabeledSlider("التعتيم ${(st.brushOpacity * 100).toInt()}%", st.brushOpacity, 0.05f..1f, Modifier.weight(1f).padding(horizontal = 4.dp)) { st.brushOpacity = it }
            }
            Tool.Move -> Hint("اسحب لتحريك الطبقة المحددة")
            Tool.Text -> Hint("المس المكان الذي تريد الكتابة فيه")
            Tool.Shape -> ShapeOptions(st)
            Tool.Fill -> Hint("المس منطقة لتعبئتها باللون الحالي")
            Tool.Eyedropper -> Hint("المس أي نقطة لالتقاط لونها")
            Tool.RectSel -> Hint("اسحب لرسم تحديد مستطيل")
            Tool.Lasso -> Hint("ارسم بإصبعك حول المنطقة المراد تحديدها")
            Tool.Wand -> Hint("المس لتحديد المناطق المتشابهة في اللون")
        }
        if (selTool || st.hasSel) SelectionActions(st)
    }
}

@Composable
fun Hint(t: String) {
    Text(t, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(vertical = 8.dp))
}

@Composable
fun SelectionActions(st: EditorState) {
    val h = st.hasSel
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        AssistChip(onClick = { st.selectAll() }, label = { Text("تحديد الكل") })
        AssistChip(onClick = { st.deselect() }, label = { Text("إلغاء") }, enabled = h)
        AssistChip(onClick = { st.invertSel() }, label = { Text("عكس") }, enabled = h)
        AssistChip(onClick = { st.copySel() }, label = { Text("نسخ") }, enabled = h,
            leadingIcon = { Icon(Icons.Filled.ContentCopy, null, Modifier.size(16.dp)) })
        AssistChip(onClick = { st.cutSel() }, label = { Text("قص") }, enabled = h,
            leadingIcon = { Icon(Icons.Filled.ContentCut, null, Modifier.size(16.dp)) })
        AssistChip(onClick = { st.paste() }, label = { Text("لصق") },
            leadingIcon = { Icon(Icons.Filled.ContentPaste, null, Modifier.size(16.dp)) })
        AssistChip(onClick = { st.fillSel() }, label = { Text("تعبئة") }, enabled = h)
        AssistChip(onClick = { st.clearSel() }, label = { Text("حذف") }, enabled = h)
    }
}

@Composable
fun ColorRow(st: EditorState) {
    Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surface)
        .horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(34.dp).clip(RoundedCornerShape(8.dp)).background(Color(st.color))
            .border(2.dp, Color.White, RoundedCornerShape(8.dp)))
        Box(Modifier.width(1.dp).height(24.dp).background(Color.Gray))
        listOf(0xFF000000, 0xFFFFFFFF, 0xFF9E9E9E, 0xFFE53935, 0xFFFB8C00, 0xFFFDD835, 0xFF43A047,
            0xFF00ACC1, 0xFF1E88E5, 0xFF8E24AA, 0xFFD81B60, 0xFF6D4C41).forEach { c ->
            val ci = c.toInt()
            Box(Modifier.size(30.dp).clip(CircleShape).background(Color(ci))
                .border(1.dp, Color.Gray, CircleShape).clickable { st.color = ci })
        }
    }
}

@Composable
fun CanvasArea(st: EditorState, modifier: Modifier) {
    Box(modifier.clipToBounds().background(Color(0xFF0D0E12))) {
        Canvas(Modifier.fillMaxSize().pointerInput(Unit) {
            awaitEachGesture {
                fun toDoc(p: Offset): Offset {
                    val s = minOf(size.width.toFloat() / st.W, size.height.toFloat() / st.H) * st.zoom
                    return Offset((p.x - size.width / 2f - st.panX) / s + st.W / 2f,
                        (p.y - size.height / 2f - st.panY) / s + st.H / 2f)
                }
                fun pr(c: PointerInputChange) =
                    if (c.type == PointerType.Stylus) c.pressure.coerceIn(0.1f, 1f) else 1f
                val down = awaitFirstDown(requireUnconsumed = false)
                val tool = st.tool
                val drawing = tool == Tool.Brush || tool == Tool.Eraser
                val selecting = tool == Tool.RectSel || tool == Tool.Lasso
                var started = when (tool) {
                    Tool.Brush, Tool.Eraser -> st.beginStroke()
                    Tool.Move -> st.beginMove()
                    Tool.Shape -> st.beginShape()
                    else -> true
                }
                var multi = false
                val start = toDoc(down.position)
                var last = start
                when (tool) {
                    Tool.Brush, Tool.Eraser -> if (started) st.dot(last.x, last.y, pr(down))
                    Tool.Eyedropper -> st.pick(last.x, last.y)
                    Tool.Fill -> st.fill(last.x, last.y)
                    Tool.Wand -> st.wand(last.x, last.y)
                    Tool.RectSel -> st.beginSel()
                    Tool.Lasso -> st.beginLasso(last.x, last.y)
                    else -> {}
                }
                down.consume()
                do {
                    val ev = awaitPointerEvent()
                    if (ev.changes.size >= 2) {
                        if (!multi) {
                            multi = true
                            if (started) {
                                if (drawing) st.cancelStroke() else if (tool == Tool.Move) st.cancelMove() else if (tool == Tool.Shape) st.cancelShape()
                                started = false
                            }
                        }
                        val z = ev.calculateZoom()
                        val pan = ev.calculatePan()
                        val c = ev.calculateCentroid()
                        if (c != Offset.Unspecified) {
                            val cx = c.x - size.width / 2f
                            val cy = c.y - size.height / 2f
                            val nz = (st.zoom * z).coerceIn(0.5f, 20f)
                            val k = nz / st.zoom
                            st.panX = cx + (st.panX - cx) * k + pan.x
                            st.panY = cy + (st.panY - cy) * k + pan.y
                            st.zoom = nz
                        }
                        ev.changes.forEach { it.consume() }
                    } else if (!multi) {
                        val ch = ev.changes.first()
                        if (ch.pressed) {
                            val p = toDoc(ch.position)
                            when (tool) {
                                Tool.Brush, Tool.Eraser -> if (started) st.segment(last.x, last.y, p.x, p.y, pr(ch))
                                Tool.Move -> if (started) st.moveTo(p.x - start.x, p.y - start.y)
                                Tool.Eyedropper -> st.pick(p.x, p.y)
                                Tool.RectSel -> st.selRect(start.x, start.y, p.x, p.y)
                                Tool.Lasso -> st.lassoTo(p.x, p.y)
                                Tool.Shape -> if (started) st.shapeTo(start.x, start.y, p.x, p.y)
                                else -> {}
                            }
                            last = p
                            ch.consume()
                        }
                    }
                } while (ev.changes.any { it.pressed })
                if (drawing) { if (started) st.endStroke() }
                else if (tool == Tool.Move) { if (started) st.endMove() }
                else if (tool == Tool.Shape) { if (started) st.endShape() }
                else if (tool == Tool.Text) { if (!multi) { st.textX = start.x; st.textY = start.y; st.textDialog = true } }
                else if (selecting) st.endSel()
            }
        }) {
            st.version
            val s = minOf(size.width / st.W, size.height / st.H) * st.zoom
            val w = (st.W * s).roundToInt(); val h = (st.H * s).roundToInt()
            val off = IntOffset((size.width / 2f + st.panX - w / 2f).roundToInt(),
                (size.height / 2f + st.panY - h / 2f).roundToInt())
            drawImage(st.composite.asImageBitmap(), dstOffset = off, dstSize = IntSize(w, h))
            if (st.hasSel) {
                st.selVersion
                drawImage(st.sel.asImageBitmap(), dstOffset = off, dstSize = IntSize(w, h))
            }
        }
        Text("${(st.zoom * 100).toInt()}%", fontSize = 11.sp,
            modifier = Modifier.align(Alignment.BottomEnd).padding(8.dp)
                .background(Color(0xAA000000), RoundedCornerShape(6.dp))
                .padding(horizontal = 8.dp, vertical = 2.dp))
    }
}

@Composable
fun LayersPanel(st: EditorState, modifier: Modifier = Modifier) {
    val sel = st.active()
    Column(modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("الطبقات", fontWeight = FontWeight.Bold)
        LazyColumn(Modifier.heightIn(max = 240.dp)) {
            items(st.layers.asReversed(), key = { it.id }) { l ->
                val on = l.id == st.selectedId
                Row(Modifier.fillMaxWidth().clip(MaterialTheme.shapes.small)
                    .background(if (on) violet.copy(alpha = 0.2f) else Color.Transparent)
                    .clickable { st.selectedId = l.id }.padding(start = 10.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(l.name, fontSize = 14.sp)
                        Text("${l.blend.label} · ${(l.opacity * 100).toInt()}%", fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton({ l.visible = !l.visible; st.refresh() }) {
                        Icon(if (l.visible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff, "إظهار/إخفاء") }
                    IconButton({ l.locked = !l.locked }) {
                        Icon(if (l.locked) Icons.Filled.Lock else Icons.Filled.LockOpen, "قفل") }
                }
            }
        }
        if (sel != null) {
            LabeledSlider("الشفافية ${(sel.opacity * 100).toInt()}%", sel.opacity, 0f..1f, Modifier) {
                sel.opacity = it; st.refresh() }
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Blend.entries.forEach { b ->
                    FilterChip(sel.blend == b, { sel.blend = b; st.refresh() }, { Text(b.label) })
                }
            }
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            AssistChip(onClick = { st.newLayer() }, label = { Text("طبقة جديدة" ) },
                leadingIcon = { Icon(Icons.Filled.Add, null, Modifier.size(18.dp)) })
            AssistChip(onClick = { st.duplicate() }, label = { Text("تكرار") })
            AssistChip(onClick = { st.moveLayer(1) }, label = { Text("رفع") })
            AssistChip(onClick = { st.moveLayer(-1) }, label = { Text("خفض") })
            AssistChip(onClick = { st.mergeDown() }, label = { Text("دمج لأسفل") })
            AssistChip(onClick = { st.delete() }, label = { Text("حذف") },
                leadingIcon = { Icon(Icons.Filled.Delete, null, Modifier.size(18.dp)) })
        }
    }
}

fun decode(ctx: Context, uri: Uri): Bitmap? {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
    var s = 1
    while (o.outWidth / s > 2400 || o.outHeight / s > 2400) s *= 2
    val o2 = BitmapFactory.Options().apply { inSampleSize = s }
    return ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
}

fun saveToGallery(ctx: Context, bmp: Bitmap) {
    val v = ContentValues().apply {
        put(MediaStore.Images.Media.DISPLAY_NAME, "PixelStudio_${System.currentTimeMillis()}.png")
        put(MediaStore.Images.Media.MIME_TYPE, "image/png")
        put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/PixelStudio")
    }
    val uri = ctx.contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v)
    if (uri == null) { Toast.makeText(ctx, "تعذّر الحفظ", Toast.LENGTH_SHORT).show(); return }
    ctx.contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
    Toast.makeText(ctx, "تم الحفظ في الصور/PixelStudio", Toast.LENGTH_LONG).show()
}
